ML dari Nol E01 — "Apa itu neural network?" — bundle chalkboard
===========================================================

Isi bundle ini (lengkap, tinggal render):
- film code E01: code/ml-dari-nol/ep01-apa-itu-neural-network/film/
- engine lemo-opuscar: core/ + styles/chalkboard/
- konsep + naskah: code/ml-dari-nol/ep01-apa-itu-neural-network/concept.md
- naskah siap-paste VO: .../script-elevenlabs.txt
- package.json (playwright-core + three)

node_modules TIDAK ikut di bundle (hemat space) — install sekali:

1. Extract bundle ini di mana aja, lalu dari folder ini (PowerShell):

   npm install

2. Chrome untuk render (sekali per jendela PowerShell):

   $env:PLAYWRIGHT_CHROME = "C:\Program Files\Google\Chrome\Application\chrome.exe"

3. Smoke test (1 still — cek GPU aktif, harus ~1-2 detik):

   node core/render/still.mjs code/ml-dari-nol/ep01-apa-itu-neural-network/film 5.0 --size 1080x1920 --out code/ml-dari-nol/ep01-apa-itu-neural-network/stills

4. Render penuh (video tanpa suara, 1080x1920, 30 fps, ~98 detik):

   node core/render/video.mjs code/ml-dari-nol/ep01-apa-itu-neural-network/film --fps 30 --workers 2 --size 1080x1920 --out code/ml-dari-nol/ep01-apa-itu-neural-network/out/ep01-video-only.mp4

5. Mux audio (setelah mix.wav dari Covryzne — extract audio pack di folder ini):

   ffmpeg -i code/ml-dari-nol/ep01-apa-itu-neural-network/out/ep01-video-only.mp4 -i mix.wav -c:v copy -af loudnorm=I=-14:TP=-1:LRA=11 -c:a aac -b:a 192k -shortest code/ml-dari-nol/ep01-apa-itu-neural-network/out/ep01-final.mp4

Catatan:
- TANPA flag --q (tilt=1&ss=1 itu khusus hd-2d, bukan chalkboard).
- ffmpeg harus ada di PATH (winget install ffmpeg).
- Film ini dibangun dengan timing VO ESTIMASI. Saat VO Rocky asli sudah
  ada, Covryzne ganti vo_times.json + regenerasi SRT, lalu render ulang.
- Repo (update terbaru selalu di sini): https://github.com/covryzne/ngonten
- Lisensi engine lemo-opuscar: lemo-LICENSE
